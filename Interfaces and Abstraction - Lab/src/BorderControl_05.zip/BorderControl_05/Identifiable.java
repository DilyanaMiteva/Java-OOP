package BorderControl_05;

public interface Identifiable {
    String getId();
}
