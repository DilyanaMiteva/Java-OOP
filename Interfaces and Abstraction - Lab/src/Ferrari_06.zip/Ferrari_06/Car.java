package Ferrari_06;

public interface Car {
    String brakes();

    String gas();
}
