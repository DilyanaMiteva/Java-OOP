package CarShopExtended_02;

public interface Rentable {
    Integer getMinRentDay();

    Double getPricePerDay();
}
