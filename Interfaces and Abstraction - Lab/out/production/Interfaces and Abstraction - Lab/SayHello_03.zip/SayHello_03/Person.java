package SayHello_03;

public interface Person {
    String getName();

    String sayHello();
}
