package MultipleInheritance_02;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
