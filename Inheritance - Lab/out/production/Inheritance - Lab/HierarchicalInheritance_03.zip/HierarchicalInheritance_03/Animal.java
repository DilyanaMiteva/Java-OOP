package HierarchicalInheritance_03;

public class Animal {
    public void eat(){
        System.out.println("eating...");
    }
}
