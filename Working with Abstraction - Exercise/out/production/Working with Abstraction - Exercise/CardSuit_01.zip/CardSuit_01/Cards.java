package CardSuit_01;

public enum Cards {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
