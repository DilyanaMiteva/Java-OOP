package BirthdayCelebrations_03;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        /*Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        List<Birthable> list = new ArrayList<>();

        while (!input.equals("End")){
            String[] tokens = input.split("\\s+");
            if (tokens.length == 5){
                list.add(new Citizen(tokens[1],Integer.parseInt(tokens[2]),
                        tokens[3], tokens[4]));
            } else {
                if (tokens[0].equals("Pet")){
                    list.add(new Pet(tokens[1], tokens[2]));
                }
            }

            input = scanner.nextLine();

        }

        int year = Integer.parseInt(scanner.nextLine());

        for (Birthable birthable : list) {
            if ()
        }
*/
    }
}
