package MultipleImplementation_02;

public interface Person {
    String getName();

    int getAge();
}
