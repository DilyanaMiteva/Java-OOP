package FoodShortage_04;

public interface Birthable {
    String getBirthDate();
}
