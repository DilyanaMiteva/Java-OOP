package Vehicles_01;

public interface Vehicles {

    void drive(double distance);

    void refuel(double liters);

}