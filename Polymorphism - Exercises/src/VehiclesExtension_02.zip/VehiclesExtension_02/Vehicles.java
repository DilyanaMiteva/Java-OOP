package VehiclesExtension_02;

public interface Vehicles {

    void drive(double distance);

    void drive(double distance,double decrease);

    void refuel(double liters);

}