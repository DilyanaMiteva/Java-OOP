package WildFarm_03;

public abstract class Felime extends Mammal{
    public Felime(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight, livingRegion);
    }
}
